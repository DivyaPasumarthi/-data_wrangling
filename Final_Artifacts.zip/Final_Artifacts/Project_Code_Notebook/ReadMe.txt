1.All the Datasets are in Folder Datasets
2.All the files generated in the code are present in IntermediateFiles
3.Final dataset is named as MergedData which is in csv format and is present outside in Root folder 

Exceuting Instructions:
Open both the notebooks:
Project_Final uses R kernel 
Project_Julia uses Julia 1.1.1 kernel

1. Start executing Project_Final 
2. In between the Project Final you will find instructions to execute Project_Julia
3. Return to Project_Final 